#!/usr/bin/env python3
"""Run tests with a worktree-scoped Docker DNS workaround on this gVisor runner.

Only new Nightscout fixture containers using this cwd's checked-in compose file
are changed. Map mongo to its actual sibling bridge IP in /etc/hosts. No service
responses, assertions, trust settings, or daemon configuration are changed.
"""
import ipaddress
import json
import pathlib
import subprocess
import sys
import threading

fixture = str(pathlib.Path('gluco-hub/tests/fixtures/nightscout-compose.yml').resolve())
log = pathlib.Path(sys.argv[1]).open('w', buffering=1)
command = sys.argv[2:]
if not command or not pathlib.Path(fixture).is_file():
    raise SystemExit('usage: run-with-compose-hosts.py LOG COMMAND [ARG...] from repo root')

def docker(*args):
    return subprocess.run(['docker', *args], capture_output=True, text=True, timeout=20)

def containers():
    result = docker('ps', '-q', '--filter', 'label=com.docker.compose.service=nightscout',
                    '--filter', 'label=com.docker.compose.project.config_files=' + fixture)
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout.split()

seen = set(containers())  # Never touch an existing stack or another worktree.
stop = threading.Event()
failures = []

def map_hosts():
    try:
        while not stop.wait(1):
            for container in set(containers()) - seen:
                info = docker('inspect', container)
                if info.returncode:
                    continue  # Container exited between list and inspect.
                ns = json.loads(info.stdout)[0]
                project = ns['Config']['Labels']['com.docker.compose.project']
                mongo_ids = docker('ps', '-q', '--filter', 'label=com.docker.compose.service=mongo',
                                   '--filter', 'label=com.docker.compose.project=' + project)
                if mongo_ids.returncode or len(mongo_ids.stdout.split()) != 1:
                    raise RuntimeError('Expected exactly one sibling MongoDB container')
                mongo = json.loads(docker('inspect', mongo_ids.stdout.strip()).stdout)[0]
                networks = ns['NetworkSettings']['Networks']
                addresses = [v['IPAddress'] for k, v in mongo['NetworkSettings']['Networks'].items()
                             if k in networks and v['IPAddress']]
                if len(addresses) != 1:
                    raise RuntimeError('Expected exactly one shared fixture bridge')
                address = str(ipaddress.ip_address(addresses[0]))
                result = docker('exec', '--user', '0', container, 'node', '-e',
                                'require("fs").appendFileSync("/etc/hosts", "\\n" + process.argv[1] + " mongo\\n")',
                                address)
                seen.add(container)
                if result.returncode:
                    raise RuntimeError(result.stderr)
                log.write(f'{container}: mongo mapped to sibling {address} on project {project}\n')
    except Exception as error:
        failures.append(str(error))
        log.write(f'ERROR: {error}\n')

thread = threading.Thread(target=map_hosts, daemon=True)
thread.start()
try:
    result = subprocess.run(command)
finally:
    stop.set()
    thread.join(timeout=25)
log.write(f'command-exit={result.returncode}; mapping-errors={len(failures)}\n')
raise SystemExit(result.returncode if result.returncode else (1 if failures else 0))
