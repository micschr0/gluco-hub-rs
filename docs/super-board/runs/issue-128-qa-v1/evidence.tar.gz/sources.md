# Official sources rechecked by QA on 2026-11-08

- https://rustsec.org/advisories/RUSTSEC-2026-0049.html
- https://rustsec.org/advisories/RUSTSEC-2026-0098.html
- https://rustsec.org/advisories/RUSTSEC-2026-0099.html
- https://rustsec.org/advisories/RUSTSEC-2026-0104.html
- https://rustsec.org/advisories/RUSTSEC-2026-0382.html
- https://rustsec.org/advisories/RUSTSEC-2025-0134.html
- https://rustsec.org/advisories/RUSTSEC-2026-0440.html
- https://rustsec.org/advisories/RUSTSEC-2024-0449.html

Patched stable WebPKI minima in the above order: 0.103.10, 0.103.12, 0.103.12, 0.103.13, 0.103.16. The final three entries are maintenance notices with no patched versions.

Published rumqttc 0.25.1 and rustls 0.23.46 sources were independently inspected from the Cargo registry (source-review.log).
