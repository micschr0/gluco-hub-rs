# Independent QA review of PR #144

Reviewed ec167afe0805fdceafbddc42a914edb4bc331b4c against merge-base with staging 583668e.
The Codex adapter requires inline review; no sub-agents were launched.

## Standards

No actionable finding. Production code and dependency versions are unchanged.
Test-only unwraps and local fixture material remain within cfg(test). The new
network option is confined to the Mosquitto test fixture, fails invalid inputs,
and leaves Docker selection unchanged when unset. The changelog covers policy.

## Spec

No actionable finding. Five feature/edge graph checks independently match the
assessment. Current official RustSec pages agree with all five patched-version
entries and the three distinct maintenance exceptions. Published rumqttc source
contains only an old-WebPKI error type; its real TLS connector delegates to the
patched rustls path. No fork or client migration was introduced. The additional
container fixture repair was explicitly authorized in recovery-context.md.

## pr-security-review

0 retained findings. The diff changes advisory policy, documentation and tests;
no production trust verifier, authorization or network destination changes.
The published fixture key is explicitly a test identity, never a trust root or
production credential. The optional network name is a trusted test-runner ENV
value, not remotely controlled input. Global advisory ignores are bounded by a
ban tested with an additional unreviewed direct parent. Maintenance debt was
assessed under the issue ACs, independently of the security skill exclusion for
outdated dependencies. No concrete new exploit candidate survived filtering.

## Test-gap ledger

| AC | Unit | Component / CLI | E2E |
|---|---|---|---|
| 1: TLS paths and five advisories | n/a: package graph/source assessment | no-default/default/mqtt-only/all-normal/all-dev logs; source-review.log; official RustSec pages | n/a: dependency identity is checked at Cargo boundary |
| 2: narrow explanations and test-only dependencies | n/a: policy text | deny-base.log, deny-no-wrapper.log, deny-additional-parent.log; graph assertions exclude both maintenance crates from production | n/a: documented rationale is manually checked against source |
| 3: patched graph and TLS errors | sink.rs:770,782,793,806 assert identity and certificate/key rejection | sink.rs:713 checks real TLS rejection and MQTT002/UnknownIssuer; cargo-deny | integration_tests/mqtt.rs:49 and multi_sink.rs:33 exercise real containers |

Changed-input edges: legacy version 0.102.8 accepted only via rumqttc, rejected
with an additional parent; baseline rejects the three previously unassessed
advisories. Network empty and non-Unicode values reject explicitly (independent
negative runs). Named network/directory mount are covered by real MQTT tests.
Dates, money, ownership, pagination, UI, accessibility: n/a to this diff.

Test-the-tests: no self-mock/tautological assertions. TLS test asserts the specific
UnknownIssuer reason, so unrelated handshake failure cannot satisfy it. The
mTLS positive test asserts both transport selection and a loaded identity.
Policy negative controls demonstrate rejection rather than a vacuous green.
No new High gap in changed behavior; no new Rust test was needed.
Test gaps (not written): Medium, existing malformed-key/empty-certificate and
SEC1/PKCS1 cases are not individually covered by this patch; the PEM implementation
is unchanged. Low, default Docker bridge behavior cannot run on this bridge-less
host; source preserves the unset branch. No optional project verifier map exists.

## Truth check

Code-grounder: no issue, confidence 97/100. Claims match sink.rs:287-355,
713-812, mosquitto.rs:66-87, deny.toml:13-38,75 and upstream published source.
Historian: no issue, confidence 96/100. Base blame confirms old incorrect
rationales; recovery history authorizes the fixture repair and records the
single-file mount failure. No ADR conflicts or reverted fixes found.
Minimum confidence: 96/100 (threshold 70). This is QA evidence, not merge approval.

## Discussion and limitations

All issue comments, PR comments, reviews and eight review threads read with
complete pagination. No prior QA/reviewer finding or unresolved human request;
existing author-note-only threads remain untouched. No UI AC: screenshots do not
apply. Upstream exploit reproductions are not claimed; locked graph + current
advisories establish the active patched versions. Keep the security human gate.
